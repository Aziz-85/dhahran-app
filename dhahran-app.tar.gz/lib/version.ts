export const APP_VERSION = '0.9.5';

