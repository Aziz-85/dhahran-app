import { SyncPlannerClient } from './SyncPlannerClient';

export default function SyncPlannerPage() {
  return <SyncPlannerClient />;
}
