import { redirect } from 'next/navigation';

export default async function SchedulePage() {
  redirect('/schedule/view');
}
