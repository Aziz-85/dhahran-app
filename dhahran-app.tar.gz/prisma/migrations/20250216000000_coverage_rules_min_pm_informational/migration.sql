-- Stored Min PM: agreed value 2 (informational only; enforcement remains AM≥PM and AM≥2)
UPDATE "CoverageRule" SET "minPM" = 2;
