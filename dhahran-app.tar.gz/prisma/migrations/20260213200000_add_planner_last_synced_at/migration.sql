-- AlterTable
ALTER TABLE "Task" ADD COLUMN "plannerLastSyncedAt" TIMESTAMP(3);
