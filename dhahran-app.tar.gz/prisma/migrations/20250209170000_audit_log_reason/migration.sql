-- AlterTable
ALTER TABLE "AuditLog" ADD COLUMN "reason" TEXT;
