# Zones map image

Add the static zones map image here:

- **Filename:** `dhahran-zones-map.png`
- **Full path:** `public/zones/dhahran-zones-map.png`

The image is shown on the **canonical Zone Inventory** page (`/inventory/zones`) to all users (Zones Map / خريطة المناطق section, Weekly tab). Use a PNG that is readable on desktop and mobile; the app displays it with `object-contain` and responsive sizing.
